<?php
/**
 * Created by PhpStorm.
 * User: elossofa
 * Date: 10/04/2018
 * Time: 12:36
 */

namespace ClientBundle\Services;


class JoueurService
{

}