<?php

namespace ClientBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ClientBundle extends Bundle
{
}
