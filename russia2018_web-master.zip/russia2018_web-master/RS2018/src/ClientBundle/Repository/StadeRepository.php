<?php
/**
 * Created by PhpStorm.
 * User: hseli
 * Date: 30/03/2018
 * Time: 19:27
 */

namespace ClientBundle\Repository;


use Doctrine\ORM\EntityRepository;

class StadeRepository extends EntityRepository
{


}